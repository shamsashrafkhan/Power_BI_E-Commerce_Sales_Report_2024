Project Name: E-Commerce Sales Report (2024)

Table of Contents:
1. E-Commerce Sales Report (2024) PBIX File
2. E-Commerce Sales Report (2024) PDF File
3. A folder containing CSV files (i.e. Customer.csv, Delivery.csv, Invoice.csv, Order.csv, Product.csv, Transaction.csv)

Description:
This project is done on Microsoft Power BI Desktop Version: 2.119.986.0 64-bit (July, 2023).
All the CSV files contain dummy data.